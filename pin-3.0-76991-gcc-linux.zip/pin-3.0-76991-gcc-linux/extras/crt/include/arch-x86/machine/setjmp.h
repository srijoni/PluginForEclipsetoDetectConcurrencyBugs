/*	$OpenBSD: setjmp.h,v 1.2 2000/08/05 22:07:32 niklas Exp $	*/
/*	$NetBSD: setjmp.h,v 1.1 1994/12/20 10:36:43 cgd Exp $	*/

/*
 * machine/setjmp.h: machine dependent setjmp-related information.
 */

#define	_JBLEN	10		/* size, in longs, of a jmp_buf */
